package com.seo.pompages;

import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.seo.utility.TestUtil;

public class SEOGenericLocator
{
	WebDriver driver;
	WebDriverWait wait;
	URL parentURL;
	String setHost;
	String setLoginURL;
	String courseCode;
	public WebDriver getDriver()
	{
		return driver;
	}
	
	public void openDriver()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\DownloadFiles\\chromedriver_105.0.5195.52 version\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(TestUtil.PAGE_LOAD_TIMEOUT));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(TestUtil.IMPLICIT_WAIT));
		wait = new WebDriverWait(driver, Duration.ofSeconds(5000));
	}
	
	public String setEnvironment(String host)
	{
		if(host.equalsIgnoreCase("prod-in"))
		{
			setHost = "https://"+host+".skillup.online";
		}
		else if(host.equalsIgnoreCase("stage-in"))
		{
			setHost = "https://"+host+".skillup.online";
		}
		else if(host.equalsIgnoreCase("qa-in"))
		{
			setHost = "https://"+host+".skillup.online";
		}
		else if(host.equalsIgnoreCase("qa"))
		{
			setHost = "https://"+host+".skillup.online";
		}
		else if(host.equalsIgnoreCase("stage"))
		{
			setHost = "https://"+host+".skillup.online";
		}
		else if(host.equalsIgnoreCase("prod"))
		{
			setHost = "https://skillup.online";
		}
		return setHost;
	}
	
	public String setSEOLoginURL(String host)
	{
		if(!host.equalsIgnoreCase("prod"))
		{
			setLoginURL = "https://"+host+"-in.skillup.online";
		}
		else
		{
			setLoginURL = "https://"+host+".skillup.online";
		}
		return setLoginURL;
	}
	
	public String getCourseCodeText(String code)
	{
		this.courseCode = code;
		String courseIDFromBrowser = "";
		String CourseCodeStatus = "false";
		HttpURLConnection huc = null;
		int respCode = 200;
		String addHosturl = this.setHost+"/courses/"+code+"";
		try
		{
			huc = (HttpURLConnection)(new URL(addHosturl).openConnection());
			huc.setRequestMethod("HEAD");
			huc.connect();
			respCode = huc.getResponseCode();
			System.out.println(respCode);
			if(respCode > 200 && (!(respCode == 308)))
			{
				System.out.println("broken link");
				System.exit(0);
			}
			else
			{
				System.out.println("un broken link");
				driver.get(addHosturl);
				WebElement checkCourseCode = driver.findElement(By.cssSelector("input#share-url"));
				String getCourseID = checkCourseCode.getAttribute("value");
				courseIDFromBrowser = getCourseID;
				System.out.println("course ID from Browser : "+courseIDFromBrowser);
				System.out.println("courseIDFrom Excel: "+code);
				if(courseIDFromBrowser.contains(code))
				{
					CourseCodeStatus = "true";
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return CourseCodeStatus;
	}
	
	public String navigateProcess()
	{
		String navigationStatus = "fail";
		try
		{
			JavascriptExecutor jse = (JavascriptExecutor) driver; //div[@class='d-flex CourseDescription_navigationBar__Zg6b3']//button[contains(text(),'Overview')]
			jse.executeScript("window.scrollBy(0,800)");
			List<WebElement> navigateFunctions = driver.findElements(By.cssSelector("div[class='d-flex FixedContentBar_navigationBar__GFCDl'] button"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("div[class='d-flex FixedContentBar_navigationBar__GFCDl'] button")));
			for(int i = 0; i < navigateFunctions.size(); i++)
			{
				if(i == 0)
				{
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
					driver.findElement(By.cssSelector("div[class='d-flex FixedContentBar_navigationBar__GFCDl'] button:nth-child(1)")).click();
					System.out.println("Overview is displayed");
					navigationStatus = "pass";
				}
				driver.navigate().refresh();
				Thread.sleep(1000);
				if(i == 1)
				{
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
					Thread.sleep(300);
					driver.findElement(By.cssSelector("div[class='d-flex FixedContentBar_navigationBar__GFCDl'] button:nth-child(2)")).click();
					System.out.println("WhySkillUpOnline? content is displayed");
					navigationStatus = "pass";
				}
				if(i == 2)
				{
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
					driver.findElement(By.cssSelector("div[class='d-flex FixedContentBar_navigationBar__GFCDl'] button:nth-child(3)")).click();
					System.out.println("FAQ is displayed");
					navigationStatus = "pass";
				}
				/*
				 * if(i == 3) {
				 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
				 * driver.findElement(By.
				 * cssSelector("div[class='d-flex FixedContentBar_navigationBar__GFCDl'] button:nth-child(4)"
				 * )).click(); }
				 */
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return navigationStatus;
	}
	
	public String freeConsultationProcess(String getFreeConsultation)
	{
		String freeConsultationStatus = "";
		try
		{
			
			if(getFreeConsultation.equals("NA"))
			{
				freeConsultationStatus = "notProcessed";
	
			}
			else
			{
				LinkedHashMap<String, String> kv = new LinkedHashMap<String, String>();
				String key = null, value = null;
				String data = getFreeConsultation;
				String[] separateData = data.split("-split-");
				for(int i = 0; i < separateData.length; i++)
				{
					System.out.println("data stored in array : "+separateData[i]);
					String[] keyValue = separateData[i].split("=");
					for(int j = 0; j < keyValue.length; j++)
					{

						if(j == 0)
						{
							key = keyValue[j];
						}
						else if(j == 1)
						{
							value = keyValue[j];
						}
						kv.put(key, value);
					}
				}
				System.out.println(kv);
				System.out.println(kv.get("name"));
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				jse.executeScript("window.scrollBy(0,300)");
				WebElement clickbutton = driver.findElement(By.cssSelector("button[class='CourseDescription_getFreeConsultationBtn__KkZ46']"));
				if(clickbutton.isDisplayed())
				{
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
					clickbutton.click();
					WebElement fullName = driver.findElement(By.cssSelector("input[name='fullname']"));
					fullName.clear();
					fullName.sendKeys(kv.get("name"));
					WebElement email = driver.findElement(By.cssSelector("div[class='GetConsultationForm_formContent__Q7Cwa'] input[name='email']"));
					email.clear();
					email.sendKeys(kv.get("mail"));
					Select select = new Select(driver.findElement(By.cssSelector("select[name='country']")));
					select.selectByVisibleText(kv.get("country"));
					WebElement mbl = driver.findElement(By.cssSelector("div[class='GetConsultationForm_formContent__Q7Cwa'] input[name='contactnumber']"));
					mbl.clear();
					mbl.sendKeys(kv.get("mbl"));
					JavascriptExecutor js = (JavascriptExecutor)driver;
					js.executeScript("arguments[0].scrollIntoView(true);", mbl);
					Select currentStatus = new Select(driver.findElement(By.cssSelector("select[name*='user']")));
					currentStatus.selectByVisibleText(kv.get("status"));
					WebElement message = driver.findElement(By.cssSelector("#message"));
					message.clear();
					message.sendKeys(kv.get("msg"));
					List<WebElement> shareConsultationForm = driver.findElements(By.cssSelector("div[class='col-12 GetConsultationForm_bySharing__ztrLr'] a"));
					for(int i = 0; i < shareConsultationForm.size(); i++)
					{
						shareConsultationForm.get(i).click();
						String parentwindow = driver.getWindowHandle();
						Set<String> allWindows = driver.getWindowHandles();
						for(String handle : allWindows)
						{
							if(!handle.equals(parentwindow))
							{
								driver.switchTo().window(handle);
								System.out.println(driver.getCurrentUrl());
								if(driver.getCurrentUrl().equalsIgnoreCase("https://stage-in.skillup.online/privacy/"))
								{
									driver.switchTo().window(handle);
									System.out.println("privacy policy window");
									driver.close();
									driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
									driver.switchTo().window(parentwindow);
								}
								else if(driver.getCurrentUrl().equals("https://stage-in.skillup.online/tos/"))
								{
									driver.switchTo().window(handle);
									System.out.println("terms of service");
									driver.close();
									driver.switchTo().window(parentwindow);
								}
							}
						}
					}
					WebElement submit = driver.findElement(By.cssSelector("div[class*='col-12 GetConsultationForm_ButtonSection'] button[type='submit']"));
					submit.click();
					try
					{
						List<WebElement> checkValidation = driver.findElements(By.cssSelector("p[class='text-danger mb-0 mt-2']"));
						if(checkValidation.size() > 0)
						{
							freeConsultationStatus = "fail";
							WebElement closePopUp = driver.findElement(By.xpath("(//button[@class='btn-close shadow-none'])[2]"));
							if(closePopUp.isDisplayed())
							{
								closePopUp.click();
							}
						}
						else
						{
							freeConsultationStatus = "pass";
						}
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return freeConsultationStatus;
	}
	String amoutWithGST;
	public void checkOutRazorpay()
	{
		WebElement checkoutAmount = driver.findElement(By.cssSelector("div[class=\"selected-plan\"] span"));
		String getCheckoutAmount = checkoutAmount.getText();
		System.out.println("checkout Razorpay amount :"+getCheckoutAmount);
		WebElement getAmountWithGST = driver.findElement(By.cssSelector("div[class='selected-plan'] span[class='h5-regular24 Accent_Red02-text']"));
		amoutWithGST = getAmountWithGST.getText();
		System.out.println(amoutWithGST);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,400)");
		WebElement completePayment = driver.findElement(By.cssSelector("button[id=\"razorpay\"]"));
		completePayment.click();
	}
	
	public void login(String loginCredential)
	{
		String[] getData = loginCredential.split("-split-");
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,200)");
		WebElement clickLoginIcon = driver.findElement(By.cssSelector("li#signinlink"));
		clickLoginIcon.click();
		System.out.println("After clicking login icon : "+driver.getCurrentUrl());
		WebElement enterEmail = driver.findElement(By.cssSelector("input#email"));
		enterEmail.sendKeys(getData[0]);
		WebElement enterPassword = driver.findElement(By.cssSelector("input#password"));
		enterPassword.sendKeys(getData[1]);
		WebElement clickLogin = driver.findElement(By.cssSelector("input#login_in"));
		clickLogin.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
	}
	
	public void selectPlan(String plan)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,300)");
		List<WebElement> listOfPlan = driver.findElements(By.cssSelector("div[class=\"owl-item active\"]"));// div[class=\"bttn\"] a
		for(int i = 0; i < listOfPlan.size(); i++)
		{
			WebElement selectPlan = listOfPlan.get(i).findElement(By.cssSelector(" div[class*=\"text-center font18\"]"));
			String getPlanText = selectPlan.getText();
			if(getPlanText.contains(plan))
			{
				WebElement clickPlan = listOfPlan.get(i).findElement(By.cssSelector(" div[class=\"bttn\"]"));
				clickPlan.click();
				break;
			}
		}
	}
	public void netBanking(String price, String priceWithTax, String paymentConfirmation)
	{
		WebElement iFrame = driver.findElement(By.cssSelector(".razorpay-checkout-frame"));
		driver.switchTo().frame(iFrame);
		List<WebElement> buttons = driver.findElements(By.cssSelector(".border-list button"));
		for(WebElement button: buttons)
		{
			WebElement label = button.findElement(By.cssSelector("div.title > div"));
			System.out.println(label.getText());
			if(label.getText().equalsIgnoreCase("Pay using Netbanking"))
			{
				label.click();
				List<WebElement> listOfNetBanking = driver.findElements(By.cssSelector("div#netb-banks label[for*='bank-radio']"));
				for(int j = 0; j < listOfNetBanking.size(); j++)
				{
					System.out.println(listOfNetBanking.get(j).getText());
					if(listOfNetBanking.get(j).getText().equalsIgnoreCase("HDFC"))
					{
						WebElement clickBank = listOfNetBanking.get(j);
						driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
						WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
					        wait.until(ExpectedConditions.elementToBeClickable(clickBank)).click(); 
						driver.findElement(By.cssSelector("div#footer[role='button']")).click();
					}
				}
			}
		}
		orderDetails();
	}
	public void card(String price, String priceWithTax, String paymentConfirmation)
	{
		WebElement iFrame = driver.findElement(By.cssSelector(".razorpay-checkout-frame"));
		driver.switchTo().frame(iFrame);
		List<WebElement> buttons = driver.findElements(By.cssSelector(".border-list button"));
		for(WebElement button: buttons)
		{
			WebElement label = button.findElement(By.cssSelector("div.title > div"));
			System.out.println(label.getText());
			if(label.getText().equalsIgnoreCase("Pay using Card"))
			{
				label.click();
				if(driver.findElement(By.cssSelector("button#otp-sec")).isDisplayed())
				{
					driver.findElement(By.cssSelector("button#otp-sec")).click();
					WebElement cardNumber = driver.findElement(By.cssSelector("input#card_number"));
					cardNumber.sendKeys("5267 3181 8797 5449");
					WebElement cardExpiry = driver.findElement(By.cssSelector("input#card_expiry"));
					cardExpiry.sendKeys("12/22");
					WebElement cardName = driver.findElement(By.cssSelector("input#card_name"));
					cardName.sendKeys("testing");
					WebElement cvv = driver.findElement(By.cssSelector("input#card_cvv"));
					cvv.sendKeys("234");
					driver.findElement(By.cssSelector("div#footer[role='button']")).click();
					driver.findElement(By.cssSelector("button#otp-sec")).click();
				}
				else
				{
					WebElement cardNumber = driver.findElement(By.cssSelector("input#card_number"));
					cardNumber.sendKeys("5267 3181 8797 5449");
					WebElement cardExpiry = driver.findElement(By.cssSelector("input#card_expiry"));
					cardExpiry.sendKeys("12/22");
					WebElement cardName = driver.findElement(By.cssSelector("input#card_name"));
					cardName.sendKeys("testing");
					WebElement cvv = driver.findElement(By.cssSelector("input#card_cvv"));
					cvv.sendKeys("234");
					driver.findElement(By.cssSelector("div#footer[role='button']")).click();
				}
			}
		}
		orderDetails();
	}
	public void orderDetails()
	{
		String paymentSelection = driver.getWindowHandle();
		Set<String> nextWindow = driver.getWindowHandles();
		Iterator<String> windows = nextWindow.iterator();
		String parentWindow = "";
		while(windows.hasNext())
		{
			String currentWindow = windows.next();
			driver.switchTo().window(currentWindow);
			if(driver.getCurrentUrl().equalsIgnoreCase("https://api.razorpay.com/v1/gateway/mocksharp/payment?key_id=rzp_test_bnV0zjfXCrrGmS"))
			{
				driver.findElement(By.cssSelector("button[class='success']")).click();
			}
			else
			{
				parentWindow = currentWindow;
			}
		}
		driver.switchTo().window(parentWindow);
		System.out.println(driver.getCurrentUrl());
		System.out.println("checkout page");
		WebElement getOrderDetails = driver.findElement(By.cssSelector("table[class=' spacing-pl8 spacing-pr8 spacing-pl20 spacing-pr20 mb table_border'] tr td"));
		System.out.println(getOrderDetails.getText());
		String amountOrderDetails = driver.findElement(By.cssSelector("table[class=' spacing-pl8 spacing-pr8 spacing-pl20 spacing-pr20 mb table_border'] tr td[class='spacing-pl8 spacing-pr20 spacing-pl20  spacing-pt8 table_lastrow last_prize table_border_bottom text_table']")).getText();
		System.out.println(amountOrderDetails);
		if(amoutWithGST.equalsIgnoreCase(amountOrderDetails))
		{
			System.out.println("both are same amount ");
		}
		else
		{
			errorCells.add(5);
		}
	}
	
	public void wallet(String price, String priceWithTax, String paymentConfirmation)
	{
		WebElement iFrame = driver.findElement(By.cssSelector(".razorpay-checkout-frame"));
		driver.switchTo().frame(iFrame);
		List<WebElement> buttons = driver.findElements(By.cssSelector(".border-list button"));
		for(WebElement button: buttons)
		{
			WebElement label = button.findElement(By.cssSelector("div.title > div"));
			System.out.println(label.getText());
			if(label.getText().equalsIgnoreCase("Pay using Wallet"))
			{
				label.click();
				WebElement phonePe = driver.findElement(By.cssSelector("div#wallet-radio-phonepe"));
				phonePe.click();
				driver.findElement(By.cssSelector("div#footer[role='button']")).click();
			}
		}
		orderDetails();
	}
	
	public void emi(String price, String priceWithTax, String paymentConfirmation)
	{
		WebElement iFrame = driver.findElement(By.cssSelector(".razorpay-checkout-frame"));
		driver.switchTo().frame(iFrame);
		List<WebElement> buttons = driver.findElements(By.cssSelector(".border-list button"));
		for(WebElement button: buttons)
		{
			WebElement label = button.findElement(By.cssSelector("div.title > div"));
			System.out.println(label.getText());
			if(label.getText().equalsIgnoreCase("Pay using EMI"))
			{
				label.click();
				driver.findElement(By.cssSelector("button#otp-sec")).click();
				WebElement cardNumber = driver.findElement(By.cssSelector("input#card_number"));
				cardNumber.sendKeys("5267 3181 8797 5449");
				WebElement cardExpiry = driver.findElement(By.cssSelector("input#card_expiry"));
				cardExpiry.sendKeys("12/22");
				WebElement cardName = driver.findElement(By.cssSelector("input#card_name"));
				cardName.sendKeys("testing");
				WebElement cvv = driver.findElement(By.cssSelector("input#card_cvv"));
				cvv.sendKeys("234");
				driver.findElement(By.cssSelector("div[class='emi-plans-text']")).click();
				driver.findElement(By.cssSelector("div#footer[role='button']")).click();
				driver.findElement(By.cssSelector("button#otp-sec")).click();
			}
		}
		orderDetails();
	}
	
	public void upi(String price, String priceWithTax, String paymentConfirmation)
	{
		WebElement iFrame = driver.findElement(By.cssSelector(".razorpay-checkout-frame"));
		driver.switchTo().frame(iFrame);
		List<WebElement> buttons = driver.findElements(By.cssSelector(".border-list button"));
		for(WebElement button: buttons)
		{
			WebElement label = button.findElement(By.cssSelector("div.title > div"));
			System.out.println(label.getText());
			if(label.getText().equalsIgnoreCase("Pay using UPI"))
			{
				label.click();
				WebElement clickUPITab = driver.findElement(By.cssSelector("div#new-vpa-field-upi"));
				clickUPITab.click();
				WebElement upiID = driver.findElement(By.cssSelector("input#vpa-upi"));
				upiID.sendKeys("success@razorpay");
				driver.findElement(By.cssSelector("div#footer[role='button']")).click();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
		orderDetails();
	}
	public void paymentProcess(String paymentModeFromExcel, String price, String priceWithTax, String paymentConfirmation)
	{
		switch(paymentModeFromExcel)
		{
		case "card":
			card(price, priceWithTax, paymentConfirmation);
			break;
		case "netbanking":
			netBanking(price, priceWithTax, paymentConfirmation);
			break;
		case "wallet":
			wallet(price, priceWithTax, paymentConfirmation);
			break;
		case "upi":
			upi(price, priceWithTax, paymentConfirmation);
			break;
		case "emi":
			emi(price, priceWithTax, paymentConfirmation);
			break;
		}
	}
	
	ArrayList<Integer> errorCells = new ArrayList<Integer>();
	public ArrayList<Integer> enrollment(String paymentModeFromExcel, String plan, String loginCredential, String price, String priceWithTax, String paymentConfirmation)
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,-1100)");
			if(driver.findElement(By.xpath("//button[contains(text(),'Enroll Now')]")).isDisplayed())
			{		
				driver.findElement(By.xpath("//button[contains(text(),'Enroll Now')]")).click();
				login(loginCredential);
				if(!driver.findElements(By.cssSelector("div[class=\"owl-item active\"]")).isEmpty())
				{
					selectPlan(plan);
				}
				checkOutRazorpay();
				paymentProcess(paymentModeFromExcel, price, priceWithTax, paymentConfirmation);
			}
			else if(driver.findElement(By.xpath("(//a[contains(text(),\"Start Now\")])[1]")).isDisplayed())
			{
				driver.findElement(By.xpath("(//a[contains(text(),\"Start Now\")])[1]")).click();
				login(loginCredential);
				if(!driver.findElements(By.cssSelector("div[class=\"owl-item active\"]")).isEmpty())
				{
					selectPlan(plan);
				}
				checkOutRazorpay();
				paymentProcess(paymentModeFromExcel, price, priceWithTax, paymentConfirmation);
				WebElement Dashboard = driver.findElement(By.cssSelector("//a[contains(text(),'Continue to your Dashboard')]"));
				Dashboard.click();
			}
			else
			{
				System.out.println("course is enrolled");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	
	public ArrayList<String> skillupOnlineLocator(ArrayList<String> skillupOnlineFromExcel)
	{
		String checkSkillupOnlineText = "";
		ArrayList<String> status = new ArrayList<String>();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,700)");
		try
		{
			for(int i = 1; i < skillupOnlineFromExcel.size(); i++)
			{
				if(skillupOnlineFromExcel.size() == 1)
				{
					if(skillupOnlineFromExcel.get(i).equals("NA"))
					{
						checkSkillupOnlineText = "notProcessed";
					}
				}
				else
				{	
					if(i == 1)
					{
						WebElement navigationButton = driver.findElement(By.cssSelector("div#why-skill-up h2[class*='_titleText']"));
						String question = navigationButton.getText().replaceAll("\\s", "").replaceAll("\u00A0", "").replaceAll("[^\\p{ASCII}]", "");
						if(question.equals(skillupOnlineFromExcel.get(i).replaceAll("\\s", "").replaceAll("\u00A0", "").replaceAll("[^\\p{ASCII}]", "")))
						{
							System.out.println("Why skill up from Browser : "+question);
							System.out.println("question is same");
							checkSkillupOnlineText = "pass";
						}
						else
						{
							System.out.println("question is not same");
							checkSkillupOnlineText = "fail";
						}
					}
					else if(i == 2)
					{
						WebElement answer = driver.findElement(By.cssSelector("section[class='WhyLearnSkillUp_mainSection__pNbU3'] div[class='WhyLearnSkillUp_mainContent__x3c7x']:not([class='WhyLearnSkillUp_titleText__N8j59'])"));
						String removeText = "Why Learn with SkillUp Online?";
						String answerText = answer.getAttribute("textContent").replaceAll("[^a-zA-Z0-9]", " ").replaceAll(removeText, "").replaceAll("\\s", "").replaceAll("\u00A0", "").replaceAll("[^\\p{ASCII}]", "");
						System.out.println(answerText);
						if(answerText.equals(skillupOnlineFromExcel.get(i).replaceAll("[^a-zA-Z0-9]", " ").replaceAll("\\s", "").replaceAll("\u00A0", "").replaceAll("[^\\p{ASCII}]", "")))
						{
							System.out.println("answer is same");
							checkSkillupOnlineText = "pass";
						}
						else
						{
							System.out.println("answer is not same");
							checkSkillupOnlineText = "fail";
						}
					}
				}
				status.add(checkSkillupOnlineText);
			}
				List<WebElement> listOfImages = driver.findElements(By.cssSelector("div[class='WhyLearnSkillUp_profitPointsSection__YTA82'] img[alt='icon']"));
				if(listOfImages.size() == 4)
				{
					System.out.println("image icons are available");
				}
				else
				{
					System.out.println("image icon is not available");
				}
				WebElement fontColor = driver.findElement(By.cssSelector("div[class='WhyLearnSkillUp_profitPointsSection__YTA82'] h2"));
				String color = fontColor.getCssValue("color");
				String str = Color.fromString(color).asHex();
				if(str.equals("#8f191f"))
				{
					System.out.println("Dark red color");
				}
				else
				{
					System.out.println("invalid color");
				}
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	public String shareLocator(String shareFromExcel)
	{
		String checkShareProcess = "";
		try
		{
			if(shareFromExcel.equals("NA"))
			{
				checkShareProcess = "notProcessed";
			}
			else
			{
				WebElement clickShareLink = driver.findElement(By.cssSelector("div.Sk_Content a img"));
				clickShareLink.click();
				WebElement copyLink = driver.findElement(By.cssSelector("div[class='share_input-text'] i[class='fa-copy-text']"));
				String getLinkText = copyLink.getText();
				copyLink.click();
				List<WebElement> share = driver.findElements(By.cssSelector("ul[class='social_sharing-sko'] li i"));
				for(int i = 0; i < share.size(); i++)
				{
					if(share.get(i).getAttribute("class").contains("twitter"))
					{
						share.get(i).click();
						String parentWindow = driver.getWindowHandle();
						Set<String> allWindow = driver.getWindowHandles();
						Iterator<String> itr = allWindow.iterator();
						while(itr.hasNext())
						{
							String childWindow = itr.next();
							if(!parentWindow.equalsIgnoreCase(childWindow))
							{
								driver.switchTo().window(childWindow);
								if(driver.getCurrentUrl().contains("twitter"))
								{
									System.out.println("twitter screen");
								}
								else if(driver.getCurrentUrl().equalsIgnoreCase("facebook"))
								{
									System.out.println("facebook screen");
								}
								else if(driver.getCurrentUrl().equalsIgnoreCase("linked"))
								{
									System.out.println("linkedIn Screen");
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return checkShareProcess;
	}
	
	public String downloadLocator(String downloadFromExcel)
	{
		String checkDownloadProcess = "";
		try
		{
			if(downloadFromExcel.equals("NA"))
			{
				downloadFromExcel = "notProcessed";
			}
			else
			{
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return checkDownloadProcess;
	}
	
	public String programLocator(String programFromExcel)
	{
		String checkProgramProcess = "";
		try
		{
			if(programFromExcel.equals("NA"))
			{
				checkProgramProcess = "notProcessed";
			}
			else
			{
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("window.scrollBy(0,-100)");
				String programText = driver.findElement(By.cssSelector("div[class='CourseDescription_infoBoxText__w49c3'] a[href]")).getAttribute("href");
				WebElement programLocator = driver.findElement(By.cssSelector("div[class='CourseDescription_infoBoxText__w49c3'] a"));
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
				if(programLocator.isDisplayed())
				{
					Thread.sleep(200);
					JavascriptExecutor jse2 = (JavascriptExecutor)driver;
					jse2.executeScript("arguments[0].scrollIntoView()", programLocator); 
					wait.until(ExpectedConditions.elementToBeClickable(programLocator)).click();
					//programLocator.click();
					String parentWindow = driver.getWindowHandle();
					Set<String> nextWindow = driver.getWindowHandles();
					for(String handle : nextWindow)
					{
						driver.switchTo().window(handle);
						if(driver.getCurrentUrl().contains(programText))
						{
							driver.switchTo().window(handle);
							System.out.println("Program window");
							checkProgramProcess = "pass";
							break;
						}
					}
					driver.close();
					driver.switchTo().window(parentWindow);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return checkProgramProcess;
	}
	public void validationProcess()
	{
		if(driver.findElement(By.cssSelector("p[class='mt-2 NewsAndUpdates_inputMessage___Y1G_ mt-1']")).isDisplayed())
		{
			System.out.println("validation message shown");
		}
		else
		{
			System.out.println("no validation message is displayed");
		}
	}
	public String subscribeLocator(String subscribeFromExcel)
	{
		String checkSubscribeProcess = "";
		try
		{
			if(subscribeFromExcel.equals("NA"))
			{
				checkSubscribeProcess = "notProcessed";
			}
			else
			{
				String splitDetails[] = subscribeFromExcel.split("-split-");
				String key = splitDetails[0];
				System.out.println(key);
				String value = splitDetails[1];
				System.out.println(value);
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("window.scrollBy(0,1000)");
				WebElement fullName = driver.findElement(By.xpath("(//input[@name='full_name'])[2]"));
				fullName.clear();
				fullName.sendKeys(key);
				validationProcess();
				WebElement email = driver.findElement(By.xpath("(//input[@name='email'])[3]"));
				email.clear();
				email.sendKeys(value);
				validationProcess();
				WebElement clickSubscribe = driver.findElement(By.xpath("(//button[contains(text(),'Subscribe')])[2]"));
				if(clickSubscribe.isDisplayed())
				{
					try
					{
						driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
						clickSubscribe.click();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						checkSubscribeProcess = "fail";
					}
					if(driver.findElement(By.cssSelector("p[class='mt-2 NewsAndUpdates_inputMessage___Y1G_ mt-1']")).isDisplayed())
					{
						System.out.println("validation message shown");
						checkSubscribeProcess = "fail";
					}
					else
					{
						checkSubscribeProcess = "pass";
					}
				}
			}
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return checkSubscribeProcess;
	}
}
