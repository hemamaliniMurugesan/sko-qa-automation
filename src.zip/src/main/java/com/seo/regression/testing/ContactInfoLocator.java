package com.seo.regression.testing;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactInfoLocator  extends ProcessLogin
{
	String launchDashboard;
	public String openSite() throws InterruptedException
	{
		launchDashboard = super.launchCourse();
		return launchDashboard;
	}
	public void individualFunction(ArrayList<String> getValuesFromExcel) throws InterruptedException
	{
		try
		{
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(90));
			Thread.sleep(1000);
			WebElement focusContact = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx']"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView(true);", focusContact);
			Thread.sleep(1000);
			WebElement selectIndividual = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] div[class='ContactForm_radioSection__sNxR8 mt-3'] ul li input#individual"));
			js.executeScript("arguments[0].scrollIntoView(true);", selectIndividual);
			if(!selectIndividual.isEnabled())
			{
				Thread.sleep(1000);
				selectIndividual.click();
				Thread.sleep(1000);
			}
			WebElement checkIndividualContent = driver.findElement(By.cssSelector("div[class='ContactForm_leftContent__VlhaM']"));
			checkIndividualContent.getText();
			if(checkIndividualContent.getText().contains("assist you."))
			{
				System.out.println("individual Information");
			}
			Thread.sleep(1000);
			WebElement focusContactInfo = driver.findElement(By.cssSelector("section#go-to-contact div[class='ContactForm_formContainer__5ygOx']"));
			WebElement fullName = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='fullname']"));
			if(!getValuesFromExcel.get(1).equalsIgnoreCase("empty"))
			{
				fullName.sendKeys(getValuesFromExcel.get(1));
			}
			else
			{
				fullName.sendKeys("");
			}
			WebElement email = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='email']"));
			if(!getValuesFromExcel.get(2).equalsIgnoreCase("empty"))
			{
				email.sendKeys(getValuesFromExcel.get(2));
			}
			else
			{
				email.sendKeys("");
			}
			WebElement country = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] select[name='country']"));
			Select selectCountry = new Select(country);
			if(!getValuesFromExcel.get(3).equalsIgnoreCase("empty"))
			{
				selectCountry.selectByValue(getValuesFromExcel.get(3));
			}
			else
			{
				selectCountry.selectByValue(getValuesFromExcel.get(3));
			}
			WebElement mobileNumber = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='contactnumber']"));
			if(!getValuesFromExcel.get(4).equalsIgnoreCase("empty"))
			{
				mobileNumber.sendKeys(getValuesFromExcel.get(4));
			}
			else
			{
				mobileNumber.sendKeys("");
			}
			WebElement currentStatus = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] select[name='userpersona']"));
			Thread.sleep(1000);
			Select selectCurrentStatus = new Select(currentStatus);
			if(!getValuesFromExcel.get(5).equalsIgnoreCase("empty"))
			{
				selectCurrentStatus.selectByVisibleText(getValuesFromExcel.get(5));
				Thread.sleep(1000);
			}
			else
			{
				selectCurrentStatus.selectByIndex(0);
			}
			List<WebElement> skills = driver.findElements(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] div[class='row ContactForm_SkillsMain__y2D6j'] div[class='col-md-6 ContactForm_CheckboxMain__pFGg3'] input"));
			//js.executeScript("window.scrollBy(0, 400)", "");
			Thread.sleep(1000);
			for(int i = 0; i < skills.size(); i++)
			{
				String getSkillValue = skills.get(i).getAttribute("id");
				String getValue[] = getValuesFromExcel.get(6).split("_");
				for(String data : getValue)
				{
					if(data.equalsIgnoreCase(getSkillValue))
					{
						if(skills.get(i).isDisplayed())
						{
							WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
							wait.until(ExpectedConditions.elementToBeClickable(skills.get(i)));
							skills.get(i).click();
							System.out.println("Skills selected : "+getSkillValue);
							Thread.sleep(500);
							if(!skills.get(i).isSelected())
							{
								skills.get(i).click();
								System.out.println("Skills selected : "+getSkillValue);
								Thread.sleep(1000);
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void academicFunction(ArrayList<String> getValuesFromExcel) throws InterruptedException
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement focusContact = driver.findElement(By.cssSelector("section#go-to-contact div[class='ContactForm_formContainer__5ygOx']"));
			js.executeScript("arguments[0].scrollIntoView(true);", focusContact);
			Thread.sleep(1000);
			WebElement selectAcademic = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] div[class='ContactForm_radioSection__sNxR8 mt-3'] ul li input#academic"));
			js.executeScript("arguments[0].scrollIntoView(true);", selectAcademic);
			Thread.sleep(1000);
			js.executeScript("window.scrollBy(0,-200)", "");
			if(selectAcademic.isDisplayed())
			{
				Thread.sleep(1000);
				selectAcademic.click();
				if(!selectAcademic.isEnabled())
				{
					Thread.sleep(1000);
					selectAcademic.click();
					Thread.sleep(1000);
				}
			}
			Thread.sleep(1000);
			WebElement checkAcademicContent = driver.findElement(By.cssSelector("div[class='ContactForm_leftContent__VlhaM']"));
			checkAcademicContent.getText();
			if(checkAcademicContent.getText().contains("academic institutions"))
			{
				System.out.println("Academic Information");
			}
			js.executeScript("window.scrollBy(0, 300)", "");
			WebElement focusContactInfo = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12']"));
			WebElement fullName = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='fullname']"));
			if(!getValuesFromExcel.get(1).equalsIgnoreCase("empty"))
			{
				fullName.sendKeys(getValuesFromExcel.get(1));
			}
			else
			{
				fullName.sendKeys("");
			}
			WebElement email = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='email']"));
			if(!getValuesFromExcel.get(2).equalsIgnoreCase("empty"))
			{
				email.sendKeys(getValuesFromExcel.get(2));
			}
			else
			{
				email.sendKeys("");
			}
			WebElement country = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] select[name='country']"));
			Select selectCountry = new Select(country);
			if(!getValuesFromExcel.get(3).equalsIgnoreCase("empty"))
			{
				selectCountry.selectByValue(getValuesFromExcel.get(3));
			}
			else
			{
				selectCountry.selectByValue(getValuesFromExcel.get(3));
			}
			WebElement mobileNumber = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='contactnumber']"));
			if(!getValuesFromExcel.get(4).equalsIgnoreCase("empty"))
			{
				mobileNumber.sendKeys(getValuesFromExcel.get(4));
			}
			else
			{
				mobileNumber.sendKeys("");
			}
			WebElement academicUniversity = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='university']"));
			if(!getValuesFromExcel.get(5).equalsIgnoreCase("empty"))
			{
				academicUniversity.sendKeys(getValuesFromExcel.get(5));
			}
			else
			{
				academicUniversity.sendKeys("");
			}
			WebElement jobTitle = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='jobtitle']"));
			if(!getValuesFromExcel.get(6).equalsIgnoreCase("empty"))
			{
				jobTitle.sendKeys(getValuesFromExcel.get(6));
			}
			else
			{
				jobTitle.sendKeys("");
			}
			WebElement message = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] textarea#message"));
			if(!getValuesFromExcel.get(7).equalsIgnoreCase("empty"))
			{
				message.sendKeys(getValuesFromExcel.get(7));
			}
			else
			{
				message.sendKeys("");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void businessFunction(ArrayList<String> getValuesFromExcel) throws InterruptedException
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Thread.sleep(1000);
			WebElement focusContact = driver.findElement(By.cssSelector("section#go-to-contact div[class='ContactForm_formContainer__5ygOx']"));
			js.executeScript("arguments[0].scrollIntoView(true);", focusContact);
			Thread.sleep(1000);
			WebElement selectBusiness = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] div[class='ContactForm_radioSection__sNxR8 mt-3'] ul li input#corporate"));
			js.executeScript("arguments[0].scrollIntoView(true);", selectBusiness);
			Thread.sleep(1000);
			js.executeScript("window.scrollBy(0, -200)", "");
			if(selectBusiness.isDisplayed())
			{
				Thread.sleep(2000);
				selectBusiness.click();
				Thread.sleep(1000);
			}
			WebElement checkBusinessContent = driver.findElement(By.cssSelector("div[class='ContactForm_leftContent__VlhaM']"));
			checkBusinessContent.getText();
			if(checkBusinessContent.getText().contains("businesses"))
			{
				System.out.println("Business Information");
			}
			WebElement focusContactInfo = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12']"));
			WebElement fullName = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='fullname']"));
			if(!getValuesFromExcel.get(1).equalsIgnoreCase("empty"))
			{
				fullName.sendKeys(getValuesFromExcel.get(1));
			}
			else
			{
				fullName.sendKeys("");
			}
			WebElement email = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='email']"));
			if(!getValuesFromExcel.get(2).equalsIgnoreCase("empty"))
			{
				email.sendKeys(getValuesFromExcel.get(2));
			}
			else
			{
				email.sendKeys("");
			}
			WebElement country = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] select[name='country']"));
			Select selectCountry = new Select(country);
			if(!getValuesFromExcel.get(3).equalsIgnoreCase("empty"))
			{
				selectCountry.selectByValue(getValuesFromExcel.get(3));
			}
			else
			{
				selectCountry.selectByValue("");
			}
			WebElement mobileNumber = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='contactnumber']"));
			if(!getValuesFromExcel.get(4).equalsIgnoreCase("empty"))
			{
				mobileNumber.sendKeys(getValuesFromExcel.get(4));
			}
			else
			{
				mobileNumber.sendKeys("");
			}
			WebElement organization = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='organization']"));
			if(!getValuesFromExcel.get(5).equalsIgnoreCase("empty"))
			{
				organization.sendKeys(getValuesFromExcel.get(5));
			}
			else
			{
				organization.sendKeys("");
			}
			js.executeScript("window.scrollBy(0, 500)", "");
			WebElement jobTitle = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] input[name='jobtitle']"));
			if(!getValuesFromExcel.get(6).equalsIgnoreCase("empty"))
			{
				jobTitle.sendKeys(getValuesFromExcel.get(6));
			}
			else
			{
				jobTitle.sendKeys("");
			}
			WebElement message = driver.findElement(By.cssSelector("div[class='ContactForm_formContainer__5ygOx'] form div[class*='col-12'] textarea#message"));
			if(!getValuesFromExcel.get(7).equalsIgnoreCase("empty"))
			{
				message.sendKeys(getValuesFromExcel.get(7));
			}
			else
			{
				message.sendKeys("");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public ArrayList<String> validation()
	{
		ArrayList<String> statusOfFunctionality = new ArrayList<String>();
		try
		{
			List<WebElement> getErrorText = driver.findElements(By.cssSelector("p[class='text-danger mb-0 mt-2']"));
			if(getErrorText.size()>0)
			{
				for(int i = 0; i < getErrorText.size(); i++)
				{
					if(getErrorText.get(i).getText().contains("full name"))
					{
						statusOfFunctionality.add("full name");
					}
					if(getErrorText.get(i).getText().contains("email address"))
					{
						statusOfFunctionality.add("email address");
					}
					if(getErrorText.get(i).getText().contains("contact number"))
					{
						statusOfFunctionality.add("contact number");
					}
					if(getErrorText.get(i).getText().contains("current status"))
					{
						statusOfFunctionality.add("current status");
					}
					if(getErrorText.get(i).getText().contains("skills"))
					{
						statusOfFunctionality.add("skills");
					}
				}
			}
			else
			{
				System.out.println("no error message");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return statusOfFunctionality;
	}
	
	public void agreePolicyTerms()
	{
		try
		{
			List<WebElement> agreeDetails = driver.findElements(By.cssSelector("div[class='col-12 ContactForm_bySharing__7DL9G'] a"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0, 100)", "");
			for(int i = 0; i < agreeDetails.size(); i++)
			{
				String n = Keys.chord(Keys.CONTROL, Keys.ENTER);
				agreeDetails.get(i).sendKeys(n);
				String parentWindow = driver.getWindowHandle();
				Set<String> windows = driver.getWindowHandles();
				for(String window : windows)
				{
					driver.switchTo().window(window);
					if(driver.getCurrentUrl().contains("privacy"))
					{
						driver.switchTo().window(window);
						System.out.println("Privacy policy window");
						driver.close();
						driver.switchTo().window(parentWindow);
					}
					if(driver.getCurrentUrl().contains("tos"))
					{
						driver.switchTo().window(window);
						System.out.println("terms of service window");
						driver.close();
						driver.switchTo().window(parentWindow);
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public ArrayList<String> checkIndividual_InvalidName(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Individual_InvalidName process started");
			this.individualFunction(dataFromExcel);
			this.agreePolicyTerms();
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			Thread.sleep(1000);
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
			}
			ErrorMessage = this.validation();
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ErrorMessage;
	}
	public ArrayList<String> checkIndividual_InvalidEmail(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Individual_InvalidEmail process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.individualFunction(dataFromExcel);
			this.agreePolicyTerms();
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ErrorMessage;
	}
	public ArrayList<String> checkIndividual_InvalidMobile(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Individual_InvalidMobile process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.individualFunction(dataFromExcel);
			this.agreePolicyTerms();
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkIndividual_WithoutSkill(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Individual_Without Skill process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.individualFunction(dataFromExcel);
			this.agreePolicyTerms();
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	
	public ArrayList<String> checkIndividual_WithoutData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage =null;
		try
		{
			System.out.println("Individual_Without Data process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.individualFunction(dataFromExcel);
			this.agreePolicyTerms();
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkIndividual_ValidData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Individual_ valid data process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.individualFunction(dataFromExcel);
			this.agreePolicyTerms();
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
				List<WebElement> checkSuccessMsgLocator = driver.findElements(By.cssSelector("div[class='col-12 undefined'] h2"));
				if(checkSuccessMsgLocator.size()>0)
				{
					System.out.println("succes msg shown : "+checkSuccessMsgLocator.get(0).getText());
				}
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_InvalidName(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Academic_InvalidName process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
			this.academicFunction(dataFromExcel);
			this.agreePolicyTerms();
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)","");
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
				wait.until(ExpectedConditions.elementToBeClickable(submit));
				submit.click();
			}
		ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_InvalidEmail(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Academic_InvalidEmail process started");
		Thread.sleep(1000);
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		Thread.sleep(2000);
		this.academicFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",submit);
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-100)","");
		if(submit.isDisplayed())
		{
			submit.click();
		}
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_InvalidMobile(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Academic_InvalidMobile process started");
		Thread.sleep(1000);
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		Thread.sleep(2000);
		this.academicFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		if(submit.isDisplayed())
		{
			submit.click();
		}
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_InvalidInstitution(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Academic_Invalid institution process started");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			Thread.sleep(2000);
			this.academicFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_WithoutJob(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Academic_without job process started");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			Thread.sleep(2000);
			this.academicFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_WithoutMessage(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Academic without message process started");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.academicFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_WithoutData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Academic_without data process started");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			Thread.sleep(2000);
			this.academicFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkAcademic_ValidData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Academic_valid data process started");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.academicFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				submit.click();
				List<WebElement> checkSuccessMsgLocator = driver.findElements(By.cssSelector("div[class='col-12 undefined'] h2"));
				if(checkSuccessMsgLocator.size()>0)
				{
					System.out.println("succes msg shown : "+checkSuccessMsgLocator.get(0).getText());
				}
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_InvalidName(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Business_InvalidName process started");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.businessFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			if(submit.isDisplayed())
			{
				submit.click();
			}
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_InvalidEmail(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> ErrorMessage = null;
		try
		{
			System.out.println("Business_InvalidEmail process started");
			((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
			ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(w.get(1));
			this.businessFunction(dataFromExcel);
			this.agreePolicyTerms();
			WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
			WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
			submit.click();
			ErrorMessage = this.validation();
			driver.close();
			driver.switchTo().window(w.get(0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_InvalidMobile(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Business_InvalidMobile process started");
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		this.businessFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		submit.click();
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_WithoutOrganization(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Business_Without Organization process started");
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		this.businessFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		submit.click();
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	
	public ArrayList<String> checkBusiness_WithoutJob(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Business_without job process started");
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		this.businessFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		submit.click();
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_WithoutMessage(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Business_without message process started");
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		this.businessFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,100)","");
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		submit.click();
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_WithoutData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Business_Without data process started");
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		this.businessFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		submit.click();
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
	public ArrayList<String> checkBusiness_ValidData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		System.out.println("Business_valid data process started");
		((JavascriptExecutor) driver).executeScript("window.open('"+launchDashboard+"')");
		ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(w.get(1));
		this.businessFunction(dataFromExcel);
		this.agreePolicyTerms();
		WebElement focus = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",focus);
		WebElement submit = driver.findElement(By.cssSelector("div[class='col-12'] button[type='submit']"));
		submit.click();
		if(submit.isDisplayed())
		{
			submit.click();
			List<WebElement> checkSuccessMsgLocator = driver.findElements(By.cssSelector("div[class='col-12 undefined'] h2"));
			if(checkSuccessMsgLocator.size()>0)
			{
				System.out.println("succes msg shown : "+checkSuccessMsgLocator.get(0).getText());
			}
		}
		ArrayList<String> ErrorMessage = this.validation();
		driver.close();
		driver.switchTo().window(w.get(0));
		return ErrorMessage;
	}
}
