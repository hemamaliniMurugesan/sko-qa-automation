package com.seo.regression.testing;

import java.util.ArrayList;

public class ContactUsValidation
{


	ArrayList<ArrayList<String>> sheetData = null;
	ContactUSLocator contactUSLocator = new ContactUSLocator();
	public ContactUsValidation(ArrayList<ArrayList<String>> sheetData) throws InterruptedException
	{
		this.sheetData = sheetData;
		contactUSLocator.openDriver();
		contactUSLocator.launchCourse();
		this.start();
	}
	
	public void start() throws InterruptedException
	{
		for(int i = 0; i < this.sheetData.size(); i++)
		{
			ArrayList<String> row = this.sheetData.get(i);
			String firstColumn = row.get(0);
			switch(firstColumn)
			{
				case "InvalidFullname":
					InvalidFullname(row);
					break;
				case "InvalidEmail":
					InvalidEmail(row);
					break;
				case "InvalidMobile":
					InvalidMobile(row);
					break;
				case"WithoutData":
					WithoutData(row);
					break;
				case "WithoutContactAbout":
					WithoutContactAbout(row);
					break;
				case"WithoutFullname":
					WithoutFullname(row);
					break;
				case"WithoutEmail":
					WithoutEmail(row);
					break;
				case"WithoutMobile":
					WithoutMobile(row);
					break;
				case"WithoutSkills":
					WithoutSkills(row);
					break;
				case"ValidData":
					ValidData(row);
					break;
			}
		}
	}
	
	public void InvalidFullname(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> fullnameValidation = contactUSLocator.checkInvalidFullname(dataFromExcel);
			for(int i = 0; i < fullnameValidation.size(); i++)
			{
				if(i == 0)
				{
					if(fullnameValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(!fullnameValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(fullnameValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(fullnameValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(fullnameValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "InvalidFullname - failed");
			}
		}
	}
	public void InvalidEmail(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> emailValidation = contactUSLocator.checkInvalidEmail(dataFromExcel);
			for(int i = 0; i < emailValidation.size(); i++)
			{
				if(i == 0)
				{
					if(emailValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(emailValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(!emailValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(emailValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(emailValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "InvalidEmail - failed");
			}
		}
	}
	public void InvalidMobile(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> mobileValidation = contactUSLocator.checkInvalidMobile(dataFromExcel);
			for(int i = 0; i < mobileValidation.size(); i++)
			{
				if(i == 0)
				{
					if(mobileValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(mobileValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(mobileValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(!mobileValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(mobileValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "InvalidMobile - failed");
			}
		}
	}
	public void WithoutData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> WithoutDataValidation = contactUSLocator.checkWithoutData(dataFromExcel);
			for(int i = 0; i < WithoutDataValidation.size(); i++)
			{
				if(i == 0)
				{
					if(WithoutDataValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(!WithoutDataValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(!WithoutDataValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(!WithoutDataValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(!WithoutDataValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "WithoutData - failed");
			}
		}
	}
	public void WithoutContactAbout(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> WithoutContactAboutValidation = contactUSLocator.checkWithoutContactAbout(dataFromExcel);
			for(int i = 0; i < WithoutContactAboutValidation.size(); i++)
				
			{
				if(i == 0)
				{
					if(!WithoutContactAboutValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(WithoutContactAboutValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(WithoutContactAboutValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(WithoutContactAboutValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(WithoutContactAboutValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "WithoutContactAbout - failed");
			}
		}
	}
	public void WithoutFullname(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> WithoutFullnameValidation = contactUSLocator.checkWithoutFullname(dataFromExcel);
			for(int i = 0; i < WithoutFullnameValidation.size(); i++)
			{
				if(i == 0)
				{
					if(WithoutFullnameValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(!WithoutFullnameValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(WithoutFullnameValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(WithoutFullnameValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(WithoutFullnameValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "WithoutFullname - failed");
			}
		}
	}
	public void WithoutEmail(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> WithoutEmailValidation = contactUSLocator.checkWithoutEmail(dataFromExcel);
			for(int i = 0; i < WithoutEmailValidation.size(); i++)
			{
				if(i == 0)
				{
					if(WithoutEmailValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(WithoutEmailValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(!WithoutEmailValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(WithoutEmailValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(WithoutEmailValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "WithoutEmail - failed");
			}
		}
	}
	public void WithoutMobile(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> WithoutMobileValidation = contactUSLocator.checkWithoutMobile(dataFromExcel);
			for(int i = 0; i < WithoutMobileValidation.size(); i++)
			{
				if(i == 0)
				{
					if(WithoutMobileValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(WithoutMobileValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(WithoutMobileValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(!WithoutMobileValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(WithoutMobileValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "WithoutMobile - failed");
			}
		}
	}
	public void WithoutSkills(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> WithoutSkillsValidation = contactUSLocator.checkWithoutSkills(dataFromExcel);
			for(int i = 0; i < WithoutSkillsValidation.size(); i++)
			{
				if(i == 0)
				{
					if(WithoutSkillsValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(WithoutSkillsValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(WithoutSkillsValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(WithoutSkillsValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 5)
				{
					if(!WithoutSkillsValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(0, "WithoutSkills - failed");
			}
		}
	}
	public void ValidData(ArrayList<String> dataFromExcel) throws InterruptedException
	{
		ArrayList<String> status = new ArrayList<String>();
		if(!dataFromExcel.contains("NA"))
		{
			ArrayList<String> ValidDataValidation = contactUSLocator.checkValidData(dataFromExcel);
			for(int i = 0; i < ValidDataValidation.size(); i++)
			{
					if(ValidDataValidation.get(i).contains("contacting us"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
					if(ValidDataValidation.get(i).contains("full name"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
					if(ValidDataValidation.get(i).contains("email"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
					if(ValidDataValidation.get(i).contains("contact"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
					if(ValidDataValidation.get(i).contains("skills"))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).get(8);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(0).set(8, (cellValue + " - failed"));
						status.add("Failed");
					}
			}
			if(status.contains("Failed"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ContactUSForm").get(9).set(0, "ValidData - failed");
			}
		}
	}
	

}
