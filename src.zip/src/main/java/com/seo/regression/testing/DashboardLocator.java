package com.seo.regression.testing;

import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DashboardLocator extends ProcessLogin
{
	public String checkSliderLink(String dataFromExcel) throws InterruptedException
	{
		String statusOfSliderScreen = "fail";
		List<WebElement> sliderPage = driver.findElements(By.cssSelector("div[class='bannersliderhome_Mainslider__w62pu'] div[class='bannersliderhome_bannerSliderH__YF848 bannersliderhome_bannerSliderHDesktOP__LpvuC'] div[class='slick-slider homebannerslider slick-initialized'] div[class*='slick-slide']"));
		Thread.sleep(2000);
		for(int i = 0; i < sliderPage.size(); i++)
		{
			Thread.sleep(3000);
			String checkPage = sliderPage.get(i).getAttribute("aria-hidden");
			Thread.sleep(1000);
			if (checkPage.contains("false"))
			{
				Thread.sleep(1000);
				String getSliderURL = sliderPage.get(i).findElement(By.cssSelector(" a")).getAttribute("href");
				System.out.println(getSliderURL);
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
				wait.until(ExpectedConditions.elementToBeClickable(sliderPage.get(i).findElement(By.cssSelector(" img"))));
				sliderPage.get(i).click();
				if(!driver.getCurrentUrl().equals(this.setHost))
				{
					statusOfSliderScreen = "pass";
					break;
				}
				else
				{
					statusOfSliderScreen = "fail";
					break;
				}
			}
		}
		driver.get(this.setHost);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(50));
		Thread.sleep(1000);
		return statusOfSliderScreen;
	}
	
	public String checkURLStatus(String data)
	{
		String status = "fail";
			HttpURLConnection huc = null;
			int respCode = 200;
			String addHosturl = data;
			/*
			 * if(data.contains("course-")) { addHosturl = this.setHost+"/courses/"+data; }
			 * else { addHosturl = this.setHost+data; }
			 */
			try
			{
				huc = (HttpURLConnection)(new URL(addHosturl).openConnection());
				huc.setRequestMethod("HEAD");
				huc.connect();
				respCode = huc.getResponseCode();
				System.out.println("status code : "+respCode + " " +addHosturl);
				if(respCode > 200)
				{
					System.out.println("broken link : "+addHosturl);
					System.out.println("response code : "+respCode);
					status = "fail";
				}
				else
				{
					System.out.println("unbroken link : "+" "+addHosturl+" "+respCode);
				//	String n = Keys.chord(Keys.CONTROL, Keys.ENTER);
					//driver.get(addHosturl);
					JavascriptExecutor js = (JavascriptExecutor) driver; 
					js. executeScript( "window. open('"+addHosturl+"');" );
					status = "success";
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return status;
	}
	
	public String checkLearningPartners()
	{
		String verifyPocess = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		List<WebElement> partnerList = driver.findElements(By.cssSelector("div[class='Collaborate_excollaborationInner__0u_r2'] ul li a"));
		for(int i = 0; i < partnerList.size(); i++)
		{
			String partnerURL = partnerList.get(i).getAttribute("href");
			String parentWindow = driver.getWindowHandle();
			verifyPocess = this.checkURLStatus(partnerURL);
			Set<String> childWindow = driver.getWindowHandles();
			for(String windows : childWindow)
			{
				if(!driver.getCurrentUrl().equalsIgnoreCase(parentWindow))
				{
					driver.switchTo().window(windows);
				}
			}
			driver.switchTo().window(parentWindow);
		}
		return verifyPocess;
	}
	
	public String checkLearningCatalog() throws InterruptedException
	{
		String verifyPocess = "fail";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)", "");
		List<WebElement> learningCatalog = driver.findElements(By.cssSelector("div[class='row'] div[class='LearningCatalog_courseList__GmNIc d-flex'] button"));
		Thread.sleep(1000);
		js.executeScript("window.scrollBy(0,-600)", "");
		for(int i = 0; i < learningCatalog.size(); i++)
		{
			Thread.sleep(1000);
			WebElement catalogs = learningCatalog.get(i);
			System.out.println("learning catalog links : "+catalogs.getText());
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
			wait.until(ExpectedConditions.elementToBeClickable(catalogs));
			catalogs.click();
			Thread.sleep(1000);
		}
			List<WebElement> learningCatalogCourses = driver.findElements(By.cssSelector("div[class='row'] div[class='col-12 px-sm-1 d-block'] div[class='slick-list'] div[class*='slick-slide'] a"));
			for(int j = 0; j < learningCatalogCourses.size(); j++)
			{
				Thread.sleep(2000);
				System.out.println(" learning catalog courses size : " +learningCatalogCourses.size());
				String checkCourse = learningCatalogCourses.get(j).getAttribute("href");
				System.out.println(" learning catalog courses Name : " +checkCourse);
				String parentWindow = driver.getWindowHandle();
				String parentURL = driver.getCurrentUrl();
				this.checkURLStatus(checkCourse);
				Set<String> childWindow = driver.getWindowHandles();
				for(String windows : childWindow)
				{
					driver.switchTo().window(windows);
					if(!(driver.getCurrentUrl().equalsIgnoreCase(parentURL)))
					{
						driver.switchTo().window(windows);
						System.out.println("learning catalog course link :"+j+" "+driver.getCurrentUrl());
						driver.close();
						verifyPocess = "success";
					}
				}
				driver.switchTo().window(parentWindow);
			}
		return verifyPocess;
	}
	
	public String checkHumanSkills()
	{
		String verifyPocess = "fail";
		List<WebElement> humanSkillsCourses = driver.findElements(By.cssSelector("div[class='col-12 undefined d-xl-block false'] div[class='row gx-3 LearningCatalog_cardRow__rFBKS'] div[class*='LearningCatalog_browserCard']"));
		for(int i = 0; i < humanSkillsCourses.size(); i++)
		{
			String getCourseLink = humanSkillsCourses.get(i).findElement(By.cssSelector("div[class='col-12 undefined d-xl-block false'] div[class='row gx-3 LearningCatalog_cardRow__rFBKS'] div[class*='LearningCatalog_browserCard'] a")).getAttribute("href");
			WebElement getCourseType = humanSkillsCourses.get(i).findElement(By.cssSelector("  div[class='RegularCourseCard_courseHeading__1Ohrn'] ul li:nth-child(1)"));
			if(getCourseType.getText().equalsIgnoreCase("Instructor-Led"))
			{
				String parentWindow = driver.getWindowHandle();
				String parentURL = driver.getCurrentUrl();
				this.checkURLStatus(getCourseLink);
				Set<String> childWindow = driver.getWindowHandles();
				for(String windows : childWindow)
				{
					driver.switchTo().window(windows);
					if(!(driver.getCurrentUrl().equalsIgnoreCase(parentURL)))
					{
						driver.switchTo().window(windows);
						List<WebElement> checkInstructorLedType = driver.findElements(By.cssSelector("div[class='d-flex gap-2'] h2"));
						for(int j = 0; j < checkInstructorLedType.size(); j++)
						{
							if(j == 0)
							{
								if(checkInstructorLedType.get(j).getText().equalsIgnoreCase("Starts on"))
								{
									System.out.println("starts on displayed");
								}
							}
							if(j == 1)
							{
								if(checkInstructorLedType.get(j).getText().equalsIgnoreCase("Duration"))
								{
									System.out.println("Duration displayed");
								}
							}
							if(j == 2)
							{
								if(checkInstructorLedType.get(j).getText().equalsIgnoreCase("Fee"))
								{
									System.out.println("Fee displayed");
								}
							}
						}
						verifyPocess = "success";
						driver.close();
					}
				}
				driver.switchTo().window(parentWindow);
			}
			else
			{
				if(getCourseType.getText().equalsIgnoreCase("Self-Paced"))
				{
					String parentWindow = driver.getWindowHandle();
					String parentURL = driver.getCurrentUrl();
					this.checkURLStatus(getCourseLink);
					Set<String> childWindow = driver.getWindowHandles();
					for(String windows : childWindow)
					{
						driver.switchTo().window(windows);
						if(!(driver.getCurrentUrl().equalsIgnoreCase(parentURL)))
						{
							driver.switchTo().window(windows);
							List<WebElement> checkSelfPacedType = driver.findElements(By.cssSelector("div[class='d-flex gap-2'] h2"));
							for(int j = 0; j < checkSelfPacedType.size(); j++)
							{
								if(j == 0)
								{
									if(checkSelfPacedType.get(j).getText().equalsIgnoreCase("Duration"))
									{
										System.out.println("Duration displayed");
									}
								}
								if(j == 1)
								{
									if(checkSelfPacedType.get(j).getText().equalsIgnoreCase("Fee"))
									{
										System.out.println("Fee displayed");
									}
								}
							}
							verifyPocess = "success";
							driver.close();
						}
					}
					driver.switchTo().window(parentWindow);
				}
			}
		}
		return verifyPocess;
	}
	
	public String checkTopTechCategories()
	{
		String verifyPocess = "fail";
		List<WebElement> topTechCategories = driver.findElements(By.cssSelector("div[class='TechCategories_exCollaborationInner__nW6ww'] ul li a"));
		for(int i = 0; i < topTechCategories.size(); i++)
		{
			String getCourseLink = topTechCategories.get(i).getAttribute("href");
			String parentWindow = driver.getWindowHandle();
			String parentURL = driver.getCurrentUrl();
			this.checkURLStatus(getCourseLink);
			Set<String> childWindow = driver.getWindowHandles();
			for(String windows : childWindow)
			{
				driver.switchTo().window(windows);
				if(!(driver.getCurrentUrl().equalsIgnoreCase(parentURL)))
				{
					driver.switchTo().window(windows);
					System.out.println("Top Categories course : "+i+" "+driver.getCurrentUrl());
					verifyPocess = "success";
					driver.close();
				}
			}
			driver.switchTo().window(parentWindow);
		}
		return verifyPocess;
	}
}
