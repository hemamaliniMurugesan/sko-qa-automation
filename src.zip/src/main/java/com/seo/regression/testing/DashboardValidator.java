package com.seo.regression.testing;

import java.util.ArrayList;

public class DashboardValidator 
{
	ArrayList<ArrayList<String>> sheetData = null;
	DashboardLocator dashboardLocator = new DashboardLocator();
	public DashboardValidator(ArrayList<ArrayList<String>> sheetData) throws InterruptedException
	{
		this.sheetData = sheetData;
		this.start();
	}
	
	public void start() throws InterruptedException
	{
		for(int i = 0; i < this.sheetData.size(); i++)
		{
			ArrayList<String> row = this.sheetData.get(i);
			String firstColumn = row.get(0);
			switch(firstColumn)
			{
			case"dotsLink":
				verifyDotsLink(row.get(1));
				break;
			case"learningPartners":
				verifyLearningPartners(row.get(1));
				break;
			case"learningCatalog":
				verifyLearningCatalog(row.get(1));
				break;
			case"humanSkills":
				verifyHumanSkills(row.get(1));
				break;
			case"topTechCategories":
				verifyTopTechCategories(row.get(1));
				break;
			}
		}
	}
	public String openSite() throws InterruptedException
	{
		dashboardLocator.openDriver();
		String dashboardURL = dashboardLocator.launchCourse();
		return dashboardURL;
	}
	String getDashboardURL = this.openSite();
	public void verifyDotsLink(String dataFromExcel) throws InterruptedException
	{
		if(!dataFromExcel.contains("NA"))
		{
			String statusOfSlider = dashboardLocator.checkSliderLink(dataFromExcel);
			if(statusOfSlider.equalsIgnoreCase("fail"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("Dashboard").get(0).set(0, "dotsLink - failed");
			}
		}
	}
	public void verifyLearningPartners(String dataFromExcel)
	{
		if(!dataFromExcel.contains("NA"))
		{
			String statusOfLearningPartners = dashboardLocator.checkLearningPartners();
			if(statusOfLearningPartners.equalsIgnoreCase("fail"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("Dashboard").get(1).set(0, "learningPartners - failed");
			}
		}
	}
	public void verifyLearningCatalog(String dataFromExcel) throws InterruptedException
	{
		if(!dataFromExcel.contains("NA"))
		{
			String statusOfLearningPartners = dashboardLocator.checkLearningCatalog();
			if(statusOfLearningPartners.equalsIgnoreCase("fail"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("Dashboard").get(2).set(0, "learningCatalog - failed");
			}
		}
	}
	public void verifyHumanSkills(String dataFromExcel)
	{
		if(!dataFromExcel.contains("NA"))
		{
			String statusOfHumanSkills = dashboardLocator.checkHumanSkills();
			if(statusOfHumanSkills.equalsIgnoreCase("fail"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("Dashboard").get(3).set(0, "humanSkills - failed");
			}
		}
	}
	
	public void verifyTopTechCategories(String dataFromExcel)
	{
		if(!dataFromExcel.contains("NA"))
		{
			String statusOfTopTechCategories = dashboardLocator.checkTopTechCategories();
			if(statusOfTopTechCategories.equalsIgnoreCase("fail"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("Dashboard").get(4).set(0, "topTechCategories - failed");
			}
		}
	}
}
