package com.seo.regression.testing;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FooterSectionLocator extends ProcessLogin
{
	
	public String verifySkillupLogo() throws InterruptedException
	{
		String getHost = this.setHost;
		if(driver.getCurrentUrl().contains(getHost))
		{
			Thread.sleep(600);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			((JavascriptExecutor) driver)
			.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Thread.sleep(1000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0, -200)", "");
			Thread.sleep(1000);
			WebElement clickLogo = driver.findElement(By.cssSelector("div[class*='Footer_footertopmenu__gu_Hf'] a[class='Footer_FTLogo__FO9jG']"));
			clickLogo.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			Thread.sleep(1000);
			driver.getCurrentUrl();
		}
		else
		{
			driver.close();
			this.openDriver();
			driver.get(getHost);
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyTwitter() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		Thread.sleep(1000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		WebElement clickTwitter = driver.findElement(By.cssSelector("ul[class*=' Footer_socialIconsSection'] li:nth-child(1)"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
		wait.until(ExpectedConditions.elementToBeClickable(clickTwitter));
		clickTwitter.click();
		Thread.sleep(800);
		String parentWindow = driver.getWindowHandle();
		Set<String> nextWindow = driver.getWindowHandles();
		Iterator<String> iterator = nextWindow.iterator();
		while (iterator.hasNext()) 
		{
			String childWindow = iterator.next();
			if(!parentWindow.equalsIgnoreCase(childWindow))
			{
				driver.switchTo().window(childWindow);
				if(driver.getCurrentUrl().contains("https://twitter.com/"))
				{
					driver.switchTo().window(childWindow);
					System.out.println("twitter window");
					driver.close();
					Thread.sleep(1000);
					driver.switchTo().window(parentWindow);
					break;
				}
				break;
			}
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver.getCurrentUrl();
	}
	
	public String verifyInstagram() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		Thread.sleep(1000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		WebElement clickInstagram = driver.findElement(By.cssSelector("ul[class*=' Footer_socialIconsSection'] li:nth-child(4)"));
		Thread.sleep(800);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
		wait.until(ExpectedConditions.elementToBeClickable(clickInstagram));
		clickInstagram.click();
		String parentWindow = driver.getWindowHandle();
		Set<String> nextWindow = driver.getWindowHandles();
		Iterator<String> iterator = nextWindow.iterator();
		while (iterator.hasNext()) 
		{
			String childWindow = iterator.next();
			if(!parentWindow.equalsIgnoreCase(childWindow))
			{
				driver.switchTo().window(childWindow);
				if(driver.getCurrentUrl().contains("https://www.instagram.com/"))
				{
					driver.switchTo().window(childWindow);
					System.out.println("instagram window");
					driver.close();
					driver.switchTo().window(parentWindow);
				}
				break;
			}
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver.getCurrentUrl();
	}
	
	public String verifyFacebook() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		Thread.sleep(1000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		WebElement clickFacebook = driver.findElement(By.cssSelector("ul[class*=' Footer_socialIconsSection'] li:nth-child(2)"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
		wait.until(ExpectedConditions.elementToBeClickable(clickFacebook));
		Thread.sleep(800);
		clickFacebook.click();
		String parentWindow = driver.getWindowHandle();
		Set<String> nextWindow = driver.getWindowHandles();
		Iterator<String> iterator = nextWindow.iterator();
		while (iterator.hasNext()) 
		{
			String childWindow = iterator.next();
			if(!parentWindow.equalsIgnoreCase(childWindow))
			{
				driver.switchTo().window(childWindow);
				if(driver.getCurrentUrl().contains("https://www.facebook.com/"))
				{
					driver.switchTo().window(childWindow);
					System.out.println("facebook window");
					driver.close();
					driver.switchTo().window(parentWindow);
				}
				break;
			}
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver.getCurrentUrl();
	}
	
	public String verifyLinkedIn() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		Thread.sleep(1000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		WebElement clickLinkedIn = driver.findElement(By.cssSelector("ul[class*=' Footer_socialIconsSection'] li:nth-child(3)"));
		Thread.sleep(800);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
		wait.until(ExpectedConditions.elementToBeClickable(clickLinkedIn));
		clickLinkedIn.click();
		String parentWindow = driver.getWindowHandle();
		Set<String> nextWindow = driver.getWindowHandles();
		Iterator<String> iterator = nextWindow.iterator();
		while (iterator.hasNext()) 
		{
			String childWindow = iterator.next();
			if(!parentWindow.equalsIgnoreCase(childWindow))
			{
				driver.switchTo().window(childWindow);
				if(driver.getCurrentUrl().contains("https://www.linkedin.com/"))
				{
					driver.switchTo().window(childWindow);
					System.out.println("linkedIn window");
					driver.close();
					driver.switchTo().window(parentWindow);
				}
				break;
			}
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver.getCurrentUrl();
	}
	
	public String verifyContactUs() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		WebElement clickContactUs = driver.findElement(By.cssSelector("div[class='Footer_ContActUsIn__ywIhS'] span img[alt='icon']"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(70));
		wait.until(ExpectedConditions.elementToBeClickable(clickContactUs));
		Thread.sleep(800);
		clickContactUs.click();
		String parentWindow = driver.getWindowHandle();
		Set<String> nextWindow = driver.getWindowHandles();
		Iterator<String> iterator = nextWindow.iterator();
		while (iterator.hasNext()) 
		{
			String childWindow = iterator.next();
			if(parentWindow.equalsIgnoreCase(childWindow))
			{
				if(driver.getCurrentUrl().contains("contact"))
				{
					System.out.println("contact window");
					String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
					String subString = StringUtils.substringBefore(getURL, "online/");
					subString = subString+"online";
					driver.get(subString);
				}	
				break;
			}
			else if(!parentWindow.equalsIgnoreCase(childWindow))
			{
				driver.switchTo().window(childWindow);
				if(driver.getCurrentUrl().contains("contact"))
				{
					driver.switchTo().window(childWindow);
					System.out.println("contact window");
					driver.close();
					driver.switchTo().window(parentWindow);
				}
				break;
			}
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver.getCurrentUrl();
	}
	
	public String verifyAboutSkillupOnline() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		List<WebElement> clickAboutSkillupOnline= driver.findElements(By.cssSelector("div[class*='Footer_FootMenu'] ul li a"));
		for(int i = 0; i < clickAboutSkillupOnline.size(); i++)
		{
			String getText = clickAboutSkillupOnline.get(i).getText();
			if(getText.equalsIgnoreCase("About SkillUp Online"))
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
				wait.until(ExpectedConditions.elementToBeClickable(clickAboutSkillupOnline.get(i)));
				Thread.sleep(800);
				clickAboutSkillupOnline.get(i).click();
				String parentWindow = driver.getWindowHandle();
				Set<String> nextWindow = driver.getWindowHandles();
				Iterator<String> iterator = nextWindow.iterator();
				while (iterator.hasNext()) 
				{
					String childWindow = iterator.next();
					if(parentWindow.equalsIgnoreCase(childWindow))
					{
						if(driver.getCurrentUrl().contains("about"))
						{
							System.out.println("about window");
							String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
							String subString = StringUtils.substringBefore(getURL, "online/");
							subString = subString+"online";
							driver.get(subString);
						}	
					}
				}
				break;
			}
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyBusiness() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(90));
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		List<WebElement> clickBusiness= driver.findElements(By.cssSelector("div[class*='Footer_FootMenu'] ul li a"));
		for(int i = 0; i < clickBusiness.size(); i++)
		{
			String getText = clickBusiness.get(i).getText();
			if(getText.equalsIgnoreCase("SkillUp Online for Business"))
			{
				Thread.sleep(800);
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(90));
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
				wait.until(ExpectedConditions.elementToBeClickable(clickBusiness.get(i)));
				clickBusiness.get(i).click();
				String parentWindow = driver.getWindowHandle();
				Set<String> nextWindow = driver.getWindowHandles();
				Iterator<String> iterator = nextWindow.iterator();
				while (iterator.hasNext()) 
				{
					String childWindow = iterator.next();
					if(parentWindow.equalsIgnoreCase(childWindow))
					{
						if(driver.getCurrentUrl().contains("enterprise"))
						{
							System.out.println("business window");
							String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
							String subString = StringUtils.substringBefore(getURL, "online/");
							subString = subString+"online";
							driver.get(subString);
						}	
					}
				}
				break;
			}
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyFaq() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		List<WebElement> clickFaq= driver.findElements(By.cssSelector("div[class*='Footer_FootMenu'] ul li a"));
		for(int i = 0; i < clickFaq.size(); i++)
		{
			String getText = clickFaq.get(i).getText();
			if(getText.equalsIgnoreCase("FAQ's"))
			{
				Thread.sleep(300);
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
				wait.until(ExpectedConditions.elementToBeClickable(clickFaq.get(i)));
				clickFaq.get(i).click();
				String parentWindow = driver.getWindowHandle();
				Set<String> nextWindow = driver.getWindowHandles();
				Iterator<String> iterator = nextWindow.iterator();
				while (iterator.hasNext()) 
				{
					String childWindow = iterator.next();
					if(parentWindow.equalsIgnoreCase(childWindow))
					{
						if(driver.getCurrentUrl().contains("faq"))
						{
							System.out.println("FAQ's window");
							String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
							String subString = StringUtils.substringBefore(getURL, "online/");
							subString = subString+"online";
							driver.get(subString);
						}	
					}
				}
				break;
			}
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyPrivacyPolicy() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(80));
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(3000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		List<WebElement> clickPrivacyPolicy= driver.findElements(By.cssSelector("div[class*='Footer_FootMenu'] ul li a"));
		for(int i = 0; i < clickPrivacyPolicy.size(); i++)
		{
			String getText = clickPrivacyPolicy.get(i).getText();
			if(getText.equalsIgnoreCase("Privacy Policy"))
			{
				Thread.sleep(500);
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
				wait.until(ExpectedConditions.elementToBeClickable(clickPrivacyPolicy.get(i)));
				clickPrivacyPolicy.get(i).click();
				Thread.sleep(1000);
				String parentWindow = driver.getWindowHandle();
				Set<String> nextWindow = driver.getWindowHandles();
				Iterator<String> iterator = nextWindow.iterator();
				while (iterator.hasNext()) 
				{
					String childWindow = iterator.next();
					if(parentWindow.equalsIgnoreCase(childWindow))
					{
						if(driver.getCurrentUrl().contains("privacy"))
						{
							System.out.println("Privacy Policy window");
							String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
							String subString = StringUtils.substringBefore(getURL, "online/");
							subString = subString+"online";
							driver.get(subString);
							break;
						}	
					}
				}
				break;
			}
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyTermsofService() throws InterruptedException
	{
		//this.scrollToFooterSection();
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(3000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		List<WebElement> clickTermsofService= driver.findElements(By.cssSelector("div[class*='Footer_FootMenu'] ul li a"));
		for(int i = 0; i < clickTermsofService.size(); i++)
		{
			String getText = clickTermsofService.get(i).getText();
			if(getText.equalsIgnoreCase("Terms of Service"))
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
				wait.until(ExpectedConditions.elementToBeClickable(clickTermsofService.get(i)));
				Thread.sleep(400);
				clickTermsofService.get(i).click();
				String parentWindow = driver.getWindowHandle();
				Set<String> nextWindow = driver.getWindowHandles();
				Iterator<String> iterator = nextWindow.iterator();
				while (iterator.hasNext()) 
				{
					String childWindow = iterator.next();
					if(parentWindow.equalsIgnoreCase(childWindow))
					{
						if(driver.getCurrentUrl().contains("tos"))
						{
							System.out.println("Terms of service window");
							String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
							String subString = StringUtils.substringBefore(getURL, "online/");
							subString = subString+"online";
							driver.get(subString);
							break;
						}	
					}
				}
				break;
			}
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyBlog() throws InterruptedException
	{
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
		List<WebElement> clickBlog= driver.findElements(By.cssSelector("div[class*='Footer_FootMenu'] ul li a"));
		for(int i = 0; i < clickBlog.size(); i++)
		{
			String getText = clickBlog.get(i).getText();
			if(getText.equalsIgnoreCase("Blog"))
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
				wait.until(ExpectedConditions.elementToBeClickable(clickBlog.get(i)));
				Thread.sleep(500);
				clickBlog.get(i).click();
				String parentWindow = driver.getWindowHandle();
				Set<String> nextWindow = driver.getWindowHandles();
				Iterator<String> iterator = nextWindow.iterator();
				while (iterator.hasNext()) 
				{
					String childWindow = iterator.next();
					if(parentWindow.equalsIgnoreCase(childWindow))
					{
						if(driver.getCurrentUrl().contains("blog"))
						{
							System.out.println("blog window");
							/*
							 * String getURL = driver.getCurrentUrl();//https://stage-in.skillup.online/
							 * String subString = StringUtils.substringBefore(getURL, "online/"); subString
							 * = subString+"online"; driver.get(subString);
							 */
							break;
						}	
					}
				}
				break;
			}
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyPopularCategories() throws InterruptedException
	{
		String getHost = this.setHost;
		if(!driver.getCurrentUrl().equalsIgnoreCase(getHost))
		{
			driver.close();
			this.openDriver();
			driver.get(getHost);
		}
		else
		{
			System.out.println("host is present");
		}
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
		List<WebElement> popularCategories = driver.findElements(By.cssSelector("div[class='Footer_PopularCategories__23uL0'] ul li a"));
		for(int i = 0; i < popularCategories.size(); i++)
		{
			 String n = Keys.chord(Keys.CONTROL, Keys.ENTER);
		      //open link in new tab
			 popularCategories.get(i).sendKeys(n);
			 String parentWindow = driver.getWindowHandle();
			 Set<String> windows = driver.getWindowHandles();
			 for(String allWindows : windows)
			 {
				 if(!parentWindow.equalsIgnoreCase(allWindows))
				 {
					 driver.switchTo().window(allWindows);
					 System.out.println(driver.getCurrentUrl());
					 driver.close();
					 driver.switchTo().window(parentWindow);
					 ((JavascriptExecutor) driver)
				     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
				 }
			 }
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyPopularCourses() throws InterruptedException
	{
		String getHost = this.setHost;
		if(!driver.getCurrentUrl().equalsIgnoreCase(getHost))
		{
			driver.close();
			this.openDriver();
			driver.get(getHost);
		}
		else
		{
			System.out.println("host is present");
		}
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
		List<WebElement> popularCourses = driver.findElements(By.cssSelector("div[class*='Footer_PopularCourses'] ul li a"));
		for(int i = 0; i < popularCourses.size(); i++)
		{
			 String n = Keys.chord(Keys.CONTROL, Keys.ENTER);
		      //open link in new tab
			 popularCourses.get(i).sendKeys(n);
			 String parentWindow = driver.getWindowHandle();
			 Set<String> windows = driver.getWindowHandles();
			 for(String allWindows : windows)
			 {
				 if(!parentWindow.equalsIgnoreCase(allWindows))
				 {
					 driver.switchTo().window(allWindows);
					 System.out.println(driver.getCurrentUrl());
					 driver.close();
					 driver.switchTo().window(parentWindow);
					 ((JavascriptExecutor) driver)
				     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
				 }
			 }
		}
		return driver.getCurrentUrl();
	}
	
	public String verifyLatestBlogs() throws InterruptedException
	{
		String getHost = this.setHost;
		if(!driver.getCurrentUrl().equalsIgnoreCase(getHost))
		{
			driver.close();
			this.openDriver();
			driver.get(getHost);
		}
		else
		{
			System.out.println("host is present");
		}
		Thread.sleep(3000);
		((JavascriptExecutor) driver)
	     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -200)", "");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
		List<WebElement> popularCourses = driver.findElements(By.cssSelector("div[class*='Footer_LatestBlogs'] div a"));
		for(int i = 0; i < popularCourses.size(); i++)
		{
			 String n = Keys.chord(Keys.CONTROL, Keys.ENTER);
		      //open link in new tab
			 popularCourses.get(i).sendKeys(n);
			 String parentWindow = driver.getWindowHandle();
			 Set<String> windows = driver.getWindowHandles();
			 for(String allWindows : windows)
			 {
				 if(!parentWindow.equalsIgnoreCase(allWindows))
				 {
					 driver.switchTo().window(allWindows);
					 System.out.println(driver.getCurrentUrl());
					 driver.close();
					 driver.switchTo().window(parentWindow);
					 ((JavascriptExecutor) driver)
				     .executeScript("window.scrollTo(0, document.body.scrollHeight)");
				 }
			 }
		}
		return driver.getCurrentUrl();
	}
}
