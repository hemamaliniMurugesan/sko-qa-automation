package com.seo.regression.testing;

import java.util.ArrayList;

public class FooterSectionValidation
{
	ArrayList<ArrayList<String>> sheetData = null;
	FooterSectionLocator footerSectionLocator = new FooterSectionLocator();
	public FooterSectionValidation(ArrayList<ArrayList<String>> sheetData) throws InterruptedException
	{
		this.sheetData = sheetData;
		this.start();
	}
	
	public void start() throws InterruptedException
	{
		for(int i = 0; i < this.sheetData.size(); i++)
		{
			ArrayList<String> row = this.sheetData.get(i);
			String firstColumn = row.get(0);
			switch(firstColumn)
			{
				case "skillupLogo":
					checkSkillupLogo();
					break;
				case "twitter":
					twitter();
					break;
				case "facebook":
					facebook();
					break;
				case "linkedIn":
					linkedIn();
					break;
				case "instagram":
					instagram();
					break;
				case "contactUs":
					contactUs();
					break;
				case "aboutSkillupOnline":
					aboutSkillupOnline();
					break;
				case "business":
					business();
					break;
				case "faq":
					faq();
					break;
				case "privacyPolicy":
					privacyPolicy();
					break;
				case "termsOfservice":
					verifyTermsofService();
					break;
				case "blog":
					verifyBlog();
					break;
				case "popularCategories":
					verifyPopularCategories();
					break;
				case "popularCourses":
					verifyPopularCourses();
					break;
				case "latestBlogs":
					verifyLatestBlogs();
					break;
			}
		}
	}
	String footerSectionURL ="";
	public String checkURL() throws InterruptedException
	{
		footerSectionLocator.openDriver();
		footerSectionURL = footerSectionLocator.launchCourse();
		return footerSectionURL;
	}
	
	public void checkSkillupLogo() throws InterruptedException
	{
		this.checkURL();
		String skillupLogoProcess = footerSectionLocator.verifySkillupLogo();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(1).set(0, "skillupLogo - failed");
		}
	}
	
	public void twitter() throws InterruptedException
	{
		String twitterProcess = footerSectionLocator.verifyTwitter();
		if(!twitterProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(2).set(0, "twitter - failed");
		}
	}
	public void facebook() throws InterruptedException
	{
		String facebookProcess = footerSectionLocator.verifyFacebook();
		if(!facebookProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(3).set(0, "facebook - failed");

		}
	}
	public void instagram() throws InterruptedException
	{
		String instagramProcess = footerSectionLocator.verifyInstagram();
		if(!instagramProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(4).set(0, "instagram - failed");

		}
	}
	public void linkedIn() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyLinkedIn();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(5).set(0, "linkedIn - failed");

		}
	}
	
	public void contactUs() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyContactUs();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(6).set(0, "contactUs - failed");

		}
	}
	public void aboutSkillupOnline() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyAboutSkillupOnline();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(7).set(0, "aboutSkillupOnline - failed");

		}
	}
	public void business() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyBusiness();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(8).set(0, "business - failed");

		}
	}
	public void faq() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyFaq();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(9).set(0, "faq - failed");

		}
	}
	public void privacyPolicy() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyPrivacyPolicy();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(10).set(0, "privacyPolicy - failed");

		}
	}
	public void verifyTermsofService() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyTermsofService();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(11).set(0, "termsOfservice - failed");
		}
	}
	public void verifyBlog() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyBlog();
		if(skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(12).set(0, "blog - failed");
		}
	}
	public void verifyPopularCategories() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyPopularCategories();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(13).set(0, "popularCategories - failed");
		}
	}
	
	public void verifyPopularCourses() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyPopularCourses();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(14).set(0, "popularCourses - failed");
		}
	}
	
	public void verifyLatestBlogs() throws InterruptedException
	{
		String skillupLogoProcess = footerSectionLocator.verifyLatestBlogs();
		if(!skillupLogoProcess.equalsIgnoreCase(footerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("FooterSection").get(14).set(0, "latestBlogs - failed");
		}
	}
}
