package com.seo.regression.testing;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ForgotPasswordLocator extends ProcessLogin
{
	public String forgotPassword(String emailFromExcel) throws InterruptedException
	{
		String status = "Failed";
		WebElement clickForgot = driver.findElement(By.cssSelector("a[class*='forgotpass']"));
		clickForgot.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		String parentWindow = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for(String allWindows : windows)
		{
			if(driver.getCurrentUrl().equalsIgnoreCase("https://stagecourses-in.skillup.online/password_reset/"))
			{
				driver.switchTo().window(allWindows);
				WebElement enterEmail = driver.findElement(By.cssSelector("input[id='email']"));
				enterEmail.sendKeys(emailFromExcel);
				WebElement clickSendemail = driver.findElement(By.cssSelector("input#reset_password"));
				clickSendemail.click();
				Thread.sleep(1000);
				String parentScreen = driver.getWindowHandle();
				Set<String> nextWindows = driver.getWindowHandles();
				for(String allWindow : nextWindows)
				{
					if(driver.getCurrentUrl().equalsIgnoreCase("https://stagecourses-in.skillup.online/password_reset/done/"))
					{
						driver.switchTo().window(allWindow);
						WebElement checkScreen = driver.findElement(By.xpath("//h4[contains(text(),'Please check your email')]"));
						String getText = checkScreen.getText();
						if(getText.equalsIgnoreCase("Please check your email"))
						{
							System.out.println("check your mail is displayed");
							WebElement clickHomePage = driver.findElement(By.xpath("//a[contains(text(),'Go to Homepage')]"));
							clickHomePage.click();
							System.out.println("Home Page : "+driver.getCurrentUrl());
							String homePage = driver.getCurrentUrl();
							if(driver.getCurrentUrl().equalsIgnoreCase(homePage))
							{
								System.out.println("home page is displayed");
								status = "Success";
							}
						}
					}
				}
			}
		}
		return status;
	}
}
