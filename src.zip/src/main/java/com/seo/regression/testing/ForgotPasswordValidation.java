package com.seo.regression.testing;

import java.util.ArrayList;

public class ForgotPasswordValidation 
{
	ArrayList<ArrayList<String>> sheetData = null;
	ForgotPasswordLocator forgotPasswordLocator = new ForgotPasswordLocator();
	
	public ForgotPasswordValidation(ArrayList<ArrayList<String>> sheetData) throws InterruptedException
	{
		this.sheetData = sheetData;
		System.out.println("forget password begins");
		forgotPasswordLocator.openDriver();
		this.start();
	}
	public void start() throws InterruptedException
	{
		for(int i = 0; i < this.sheetData.size(); i++)
		{
			ArrayList<String> row = this.sheetData.get(i);
			String firstColumn = row.get(0);
			switch(firstColumn)
			{
				case "url":
					url(row.get(1));
				break;
				case "forgotPwd":
					checkForgotPwd(row.get(1));
					break;
			}
		}
	}
	public String url(String urlFromExcel)
	{
		return forgotPasswordLocator.launchCourse(urlFromExcel);
	}
	
	public void checkForgotPwd(String emailFromExcel) throws InterruptedException
	{
		String status = "Failed";
		status = forgotPasswordLocator.forgotPassword(emailFromExcel);
		if(!status.equalsIgnoreCase("Success"))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("ForGotPwd").get(1).set(1, "forgotPwd - failed");
		}
	}
}
