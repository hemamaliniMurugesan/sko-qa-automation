package com.seo.regression.testing;

import java.util.ArrayList;

public class HeaderSectionValidation extends OpenWebsite
{
	ArrayList<ArrayList<String>> sheetData = null;
	HeaderSectionLocator headerSectionLocator = new HeaderSectionLocator();
	public HeaderSectionValidation(ArrayList<ArrayList<String>> sheetData) throws InterruptedException
	{
		this.sheetData = sheetData;
		this.checkURL();
		this.start();
	}
	
	public void start() throws InterruptedException
	{
		int j = 1;
		while(j<=1)
		{
			System.out.println("Time of execution : "+j);
			for(int i = 0; i < this.sheetData.size(); i++)
			{
				ArrayList<String> row = this.sheetData.get(i);
				String firstColumn = row.get(0);
				switch(firstColumn)
				{
					case "skillupLogo":
						checkSkillupLogo(row.get(1));
						break;
					case "contactUs":
						checkContactUs();
						break;
					case "business":
						checkBusiness();
						break;
					case "blog":
						checkBlog();
						break;
					case "categories":
						checkCategories();
						break;
					case "popularCourses":
						checkPopularCourses();
						break;
					case "login":
						checkLogin();
						break;
					case "learningPartner":
						checkLearningPartner();
						break;
					case "signUP":
						checkSignUP(row.get(1));
						break;
					case "searchCourses":
						checkSearchCourses(row);
						break;
				}
			}
			j++;
		}
		
	}
	String headerSectionURL ="";
	public String checkURL() throws InterruptedException
	{
		headerSectionLocator.openDriver();
		headerSectionURL = headerSectionLocator.launchCourse();
		return headerSectionURL;
	}
	public void checkSkillupLogo(String data) throws InterruptedException
	{
		if(!data.contains("NA"))
		{
			String skillupLogoProcess = headerSectionLocator.checkSkillupLogo();
			if(!skillupLogoProcess.equalsIgnoreCase(headerSectionURL))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(1).set(0, "skillupLogo - failed");
			}
		}
	}
	
	public void checkLearningPartner() throws InterruptedException
	{
		String learningPartner = headerSectionLocator.verifyLearningPartner();
		if(!learningPartner.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(2).set(0, "contactUs - failed");
		}
	}
	public void checkContactUs() throws InterruptedException
	{
		String contactUSProcess = headerSectionLocator.checkContactUs();
		if(!contactUSProcess.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(2).set(0, "contactUs - failed");
		}
	}
	public void checkBusiness()
	{
		String businessProcess = headerSectionLocator.checkBusiness();
		if(!businessProcess.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(3).set(0, "business - failed");
		}
	}
	public void checkBlog() throws InterruptedException
	{
		String blogProcess = headerSectionLocator.checkBlog();
		if(!blogProcess.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(4).set(0, "blog - failed");
		}
	}
	public void checkCategories()
	{
		String skillupLogoProcess = headerSectionLocator.checkCategories();
		if(!skillupLogoProcess.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(5).set(0, "popularCategories - failed");
		}
	}
	public void checkPopularCourses()
	{
		String popularCouseProcess = headerSectionLocator.checkPopularCourses();
		if(!popularCouseProcess.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(6).set(0, "popularCourses - failed");
		}
	}
	public void checkLogin()
	{
		String loginProcess = headerSectionLocator.checkLogin();
		if(!loginProcess.equalsIgnoreCase(headerSectionURL))
		{
			RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(7).set(0, "login - failed");
		}
	}
	public void checkSignUP(String data) throws InterruptedException
	{
		if(!data.contains("NA"))
		{
			String signUpProcess = headerSectionLocator.checkSignUP();
			if(!signUpProcess.equalsIgnoreCase(headerSectionURL))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(8).set(0, "signUP - failed");
			}
		}
	}
	public void checkSearchCourses(ArrayList<String> data)
	{
		if(!data.contains("NA"))
		{
			String searchProcess = headerSectionLocator.checkSearchCourses(data.get(1));
			if(searchProcess.equalsIgnoreCase("fail"))
			{
				RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("HeaderSection").get(9).set(0, "searchCourses - failed");
			}
		}
	}
}
