package com.seo.regression.testing;

import java.util.ArrayList;

public class SignUpValidation
{
	String result = "failed";
	ArrayList<ArrayList<String>> sheetData = null;
	SignUpLocator signUpLocator = new SignUpLocator();
	String userName;
	
	public SignUpValidation(ArrayList<ArrayList<String>> sheetData) throws InterruptedException
	{
		this.sheetData = sheetData;
		signUpLocator.opensignUpPage();
		System.out.println("Sign up validation begins");
		this.start();
	}
	
	public void start() throws InterruptedException
	{
		for(int i = 0; i < this.sheetData.size(); i++)
		{
			ArrayList<String> row = this.sheetData.get(i);
			String firstColumn = row.get(0);
			switch(firstColumn)
			{
				case "invalidFullname":
					invalidFullname(row);
					break;
				case "invalidEmail":
					emailValidation(row);
					break;
				case "invalidPassword":
					passwordValidation(row);
					break;
				case "invalidMobile":
					mobileValidation(row);
					break;
				case "validData":
					validData(row);
					break;
					
			}
		}
	}
	
	
	public void invalidFullname(ArrayList<String> dataFromExcel)
	{
		ArrayList<Integer> fieldValidationValue;
		try
		{
			ArrayList<Integer> verifyFullName = signUpLocator.checkFullName(sheetData.get(0));
			fieldValidationValue = verifyFullName;
			ArrayList<String> status = new ArrayList<String>();
			for(int i = 0; i < fieldValidationValue.size(); i++)
			{
				if(i == 0)
				{
					if(!fieldValidationValue.get(i).equals(1))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(0).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(fieldValidationValue.get(i).equals(2))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(0).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 2)
				{
					if(fieldValidationValue.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(0).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 3)
				{
					if(fieldValidationValue.get(i).equals(4))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).get(4);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(0).set(4, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 4)
				{
					if(fieldValidationValue.get(i).equals(5))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(0).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(status.contains("Failed"))
				{
					String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).get(0);
					RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(0).set(0, (cellValue + " - failed"));
				}
				 
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void emailValidation(ArrayList<String> dataFromExcel)
	{
		ArrayList<String> status = new ArrayList<String>();
		try
		{
			ArrayList<Integer> verifyEmail = signUpLocator.checkEmail(sheetData.get(1));
			for(int i = 0; i < verifyEmail.size(); i++)
			{
				if(i == 0)
				{
					if(verifyEmail.get(i).equals(1))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 1)
				{
					if(!verifyEmail.get(i).equals(2))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(i == 2)
				{
					if(verifyEmail.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				if(status.contains("Failed"))
				{
					RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(1).set(0, "invalidEmail - failed"); 
				}
				 
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void passwordValidation(ArrayList<String> dataFromExcel)
	{
		ArrayList<String> status = new ArrayList<String>();
		try
		{
			ArrayList<Integer> verifyPassword = signUpLocator.checkPassword(sheetData.get(2));
			for(int i = 0; i < verifyPassword.size(); i++)
			{
				if(i == 0)
				{
					if(verifyPassword.get(i).equals(1))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 1)
				{
					if(verifyPassword.get(i).equals(2))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 2)
				{
					if(!verifyPassword.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 3)
				{
					if(verifyPassword.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).get(4);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).set(4, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 4)
				{
					if(verifyPassword.get(i).equals(4))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}	
				}
				if(status.contains("Failed"))
				{
					RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(2).set(0, "invalidPassword - failed"); 
				}
				 
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	public void mobileValidation(ArrayList<String> dataFromExcel)
	{
		ArrayList<String> status = new ArrayList<String>();
		try
		{
			ArrayList<Integer> verifyMobileField = signUpLocator.checkMobileNumber(sheetData.get(3));
			for(int i = 0; i < verifyMobileField.size(); i++)
			{
				if(i == 0)
				{
					if(verifyMobileField.get(i).equals(1))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 1)
				{
					if(verifyMobileField.get(i).equals(2))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 2)
				{
					if(verifyMobileField.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 3)
				{
					if(verifyMobileField.get(i).equals(4))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).get(4);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).set(4, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 4)
				{
					if(!verifyMobileField.get(i).equals(4))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}	
				}
				if(status.contains("Failed"))
				{
					RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(3).set(0, "invalidMobileNumber - failed"); 
				}
				 
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void validData(ArrayList<String> dataFromExcel)
	{
		ArrayList<String> status = new ArrayList<String>();
		
		try
		{
			ArrayList<Integer> verifyValidData = signUpLocator.checkSignupWithValidData(sheetData.get(4));
			for(int i = 0; i < verifyValidData.size(); i++)
			{
				if(i == 0)
				{
					if(verifyValidData.get(i).equals(1))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(5).get(1);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).set(1, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 1)
				{
					if(verifyValidData.get(i).equals(2))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(5).get(2);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).set(2, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 2)
				{
					if(verifyValidData.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(5).get(3);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).set(3, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 3)
				{
					if(verifyValidData.get(i).equals(3))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(5).get(4);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).set(4, (cellValue + " - failed"));
						status.add("Failed");
					}
				}
				else if(i == 4)
				{
					if(verifyValidData.get(i).equals(4))
					{
						String cellValue = RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(5).get(5);
						RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).set(5, (cellValue + " - failed"));
						status.add("Failed");
					}	
				}
				if(status.contains("Failed"))
				{
					RegressionTesting.EXCEL_DATA_AS_SHEEET_NAME_AND_ROWS_MAP.get("SignUp").get(4).set(0, "validData - failed"); 
				}
				 
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
