package com.seo.utility;

public class TestUtil 
{
	public static long PAGE_LOAD_TIMEOUT = 20; // set time to wait for loading of the page
	public static long IMPLICIT_WAIT = 10;//the web driver will wait for the element for that time before throwing an exception
}
